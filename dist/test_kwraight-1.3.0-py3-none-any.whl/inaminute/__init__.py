"""Get delayed"""
